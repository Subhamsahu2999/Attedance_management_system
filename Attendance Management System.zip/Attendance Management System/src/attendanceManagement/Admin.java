package attendanceManagement;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;

public class Admin {

	private JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Admin window = new Admin();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Admin() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 1440, 758);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Welcome, Admin");
		lblNewLabel.setFont(new Font("Times New Roman", Font.PLAIN, 30));
		lblNewLabel.setBounds(29, 14, 266, 45);
		frame.getContentPane().add(lblNewLabel);
		
		JButton btnNewButton = new JButton("Logout");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
						Login.main(new String[]{});
						frame.dispose();
			}
		});
		btnNewButton.setFont(new Font("Times New Roman", Font.PLAIN, 20));
		btnNewButton.setBounds(1261, 10, 131, 49);
		frame.getContentPane().add(btnNewButton);
		
		JButton btnViewTeachers = new JButton("View Faculty");
		btnViewTeachers.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ViewFaculty.main(new String[]{});
				frame.dispose();
			}
		});
		btnViewTeachers.setFont(new Font("Times New Roman", Font.PLAIN, 20));
		btnViewTeachers.setBounds(113, 285, 164, 49);
		frame.getContentPane().add(btnViewTeachers);
		
		JButton btnAddTeachers = new JButton("Add Faculty");
		btnAddTeachers.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
						AddFaculty.main(new String[]{});
						frame.dispose();
			}
		});
		btnAddTeachers.setFont(new Font("Times New Roman", Font.PLAIN, 20));
		btnAddTeachers.setBounds(113, 163, 164, 49);
		frame.getContentPane().add(btnAddTeachers);
		
		JButton btnMarkTeacherAttendance = new JButton("Mark Faculty Attendance");
		btnMarkTeacherAttendance.setFont(new Font("Times New Roman", Font.PLAIN, 20));
		btnMarkTeacherAttendance.setBounds(590, 163, 259, 49);
		frame.getContentPane().add(btnMarkTeacherAttendance);
		
		JButton btnViewStudents = new JButton("View Students");
		btnViewStudents.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ViewStudent.main(new String[]{});
			}
		});
		btnViewStudents.setFont(new Font("Times New Roman", Font.PLAIN, 20));
		btnViewStudents.setBounds(307, 285, 164, 49);
		frame.getContentPane().add(btnViewStudents);
		
		JButton btnAddStudents = new JButton("Add Students");
		btnAddStudents.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				AddStudent.main(new String[]{});
				frame.dispose();
			}
		});
		btnAddStudents.setFont(new Font("Times New Roman", Font.PLAIN, 20));
		btnAddStudents.setBounds(307, 163, 164, 49);
		frame.getContentPane().add(btnAddStudents);
		
		JButton btnUpdateTeacherAttendance = new JButton("Update Faculty Attendance");
		btnUpdateTeacherAttendance.setFont(new Font("Times New Roman", Font.PLAIN, 20));
		btnUpdateTeacherAttendance.setBounds(590, 285, 259, 49);
		frame.getContentPane().add(btnUpdateTeacherAttendance);
		
		JLabel lblNewLabel_1 = new JLabel("Viewing/Adding/Removing");
		lblNewLabel_1.setFont(new Font("Times New Roman", Font.PLAIN, 20));
		lblNewLabel_1.setBounds(192, 120, 222, 33);
		frame.getContentPane().add(lblNewLabel_1);
		
		JLabel lblNewLabel_1_1 = new JLabel("Attendance");
		lblNewLabel_1_1.setFont(new Font("Times New Roman", Font.PLAIN, 20));
		lblNewLabel_1_1.setBounds(659, 120, 164, 33);
		frame.getContentPane().add(lblNewLabel_1_1);
		
		JButton btnRemoveTeacher = new JButton("Remove Teacher");
		btnRemoveTeacher.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnRemoveTeacher.setFont(new Font("Times New Roman", Font.PLAIN, 20));
		btnRemoveTeacher.setBounds(102, 412, 175, 49);
		frame.getContentPane().add(btnRemoveTeacher);
		
		JButton btnRemStudent = new JButton("Remove Student");
		btnRemStudent.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e)  {
					DeleteStudent.main(new String[]{});
					frame.dispose();
			}
		});
		btnRemStudent.setFont(new Font("Times New Roman", Font.PLAIN, 20));
		btnRemStudent.setBounds(307, 412, 175, 49);
		frame.getContentPane().add(btnRemStudent);
		
		JButton btnNewButton_1 = new JButton("View/Edit\r\n");
		btnNewButton_1.setFont(new Font("Times New Roman", Font.PLAIN, 20));
		btnNewButton_1.setBounds(631, 641, 130, 33);
		frame.getContentPane().add(btnNewButton_1);
		
		JComboBox comboBox = new JComboBox();
		comboBox.setFont(new Font("Times New Roman", Font.PLAIN, 20));
		comboBox.setModel(new DefaultComboBoxModel(new String[] {"MBA", "MCA", "M-COM", "MSC", "BBA", "BCA", "B-TECH", "BSC"}));
		comboBox.setBounds(721, 544, 170, 33);
		frame.getContentPane().add(comboBox);
		
		JLabel lblNewLabel_1_1_1 = new JLabel("Department");
		lblNewLabel_1_1_1.setFont(new Font("Times New Roman", Font.PLAIN, 20));
		lblNewLabel_1_1_1.setBounds(555, 544, 115, 33);
		frame.getContentPane().add(lblNewLabel_1_1_1);
		
		JLabel lblNewLabel_1_1_1_1 = new JLabel("Time Table");
		lblNewLabel_1_1_1_1.setFont(new Font("Times New Roman", Font.PLAIN, 20));
		lblNewLabel_1_1_1_1.setBounds(646, 440, 102, 33);
		frame.getContentPane().add(lblNewLabel_1_1_1_1);
		
		JButton btnUpdatePassword = new JButton("Update Password");
		btnUpdatePassword.setFont(new Font("Times New Roman", Font.PLAIN, 20));
		btnUpdatePassword.setBounds(921, 10, 259, 49);
		frame.getContentPane().add(btnUpdatePassword);
		
		JLabel lblNewLabel_1_1_2 = new JLabel("Assign Faculty");
		lblNewLabel_1_1_2.setFont(new Font("Times New Roman", Font.PLAIN, 20));
		lblNewLabel_1_1_2.setBounds(1090, 120, 164, 33);
		frame.getContentPane().add(lblNewLabel_1_1_2);
		
		JButton btnAssignFacultyTo = new JButton("Assign Faculty \r\nTo A Subject");
		btnAssignFacultyTo.setFont(new Font("Times New Roman", Font.PLAIN, 20));
		btnAssignFacultyTo.setBounds(1006, 163, 312, 79);
		frame.getContentPane().add(btnAssignFacultyTo);
		
		JLabel lblNewLabel_1_1_2_1 = new JLabel("Subject\r\n");
		lblNewLabel_1_1_2_1.setFont(new Font("Times New Roman", Font.PLAIN, 20));
		lblNewLabel_1_1_2_1.setBounds(1106, 304, 84, 33);
		frame.getContentPane().add(lblNewLabel_1_1_2_1);
		
		JButton btnAddSubject = new JButton("Add Subject");
		btnAddSubject.setFont(new Font("Times New Roman", Font.PLAIN, 20));
		btnAddSubject.setBounds(865, 372, 259, 49);
		frame.getContentPane().add(btnAddSubject);
		
		JButton btnViewSubjectList = new JButton("View Subject List");
		btnViewSubjectList.setFont(new Font("Times New Roman", Font.PLAIN, 20));
		btnViewSubjectList.setBounds(1145, 372, 259, 49);
		frame.getContentPane().add(btnViewSubjectList);
	}
}
