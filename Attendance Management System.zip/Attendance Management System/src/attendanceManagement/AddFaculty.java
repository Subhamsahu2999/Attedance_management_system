package attendanceManagement;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPasswordField;

import java.awt.Font;
import javax.swing.JTextField;
import com.toedter.calendar.JDateChooser;
import javax.swing.JRadioButton;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class AddFaculty {

	private JFrame frame;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_4;
	private JTextField textField_5;
	private JPasswordField passwordField;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					AddFaculty window = new AddFaculty();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public AddFaculty() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 1447, 762);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Faculty Form");
		lblNewLabel.setFont(new Font("Times New Roman", Font.PLAIN, 30));
		lblNewLabel.setBounds(10, 10, 253, 41);
		frame.getContentPane().add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("First Name");
		lblNewLabel_1.setFont(new Font("Times New Roman", Font.PLAIN, 22));
		lblNewLabel_1.setBounds(155, 112, 108, 28);
		frame.getContentPane().add(lblNewLabel_1);
		
		textField = new JTextField();
		textField.setBounds(279, 112, 150, 33);
		frame.getContentPane().add(textField);
		textField.setColumns(10);
		
		JLabel lblNewLabel_1_1 = new JLabel("Last Name");
		lblNewLabel_1_1.setFont(new Font("Times New Roman", Font.PLAIN, 22));
		lblNewLabel_1_1.setBounds(460, 112, 108, 28);
		frame.getContentPane().add(lblNewLabel_1_1);
		
		textField_1 = new JTextField();
		textField_1.setColumns(10);
		textField_1.setBounds(578, 112, 150, 33);
		frame.getContentPane().add(textField_1);
		
		JLabel lblNewLabel_1_2 = new JLabel("Age");
		lblNewLabel_1_2.setFont(new Font("Times New Roman", Font.PLAIN, 22));
		lblNewLabel_1_2.setBounds(155, 194, 108, 28);
		frame.getContentPane().add(lblNewLabel_1_2);
		
		JLabel lblNewLabel_1_3 = new JLabel("Address");
		lblNewLabel_1_3.setFont(new Font("Times New Roman", Font.PLAIN, 22));
		lblNewLabel_1_3.setBounds(155, 278, 108, 28);
		frame.getContentPane().add(lblNewLabel_1_3);
		
		JLabel lblNewLabel_1_4 = new JLabel("DOB");
		lblNewLabel_1_4.setFont(new Font("Times New Roman", Font.PLAIN, 22));
		lblNewLabel_1_4.setBounds(155, 363, 108, 28);
		frame.getContentPane().add(lblNewLabel_1_4);
		
		JLabel lblNewLabel_1_5 = new JLabel("Email ID");
		lblNewLabel_1_5.setFont(new Font("Times New Roman", Font.PLAIN, 22));
		lblNewLabel_1_5.setBounds(854, 112, 108, 28);
		frame.getContentPane().add(lblNewLabel_1_5);
		
		JLabel lblNewLabel_1_6 = new JLabel("Password");
		lblNewLabel_1_6.setFont(new Font("Times New Roman", Font.PLAIN, 22));
		lblNewLabel_1_6.setBounds(854, 194, 108, 28);
		frame.getContentPane().add(lblNewLabel_1_6);
		
		JLabel lblNewLabel_1_5_1 = new JLabel("Contact");
		lblNewLabel_1_5_1.setFont(new Font("Times New Roman", Font.PLAIN, 22));
		lblNewLabel_1_5_1.setBounds(155, 447, 108, 28);
		frame.getContentPane().add(lblNewLabel_1_5_1);
		
		textField_2 = new JTextField();
		textField_2.setColumns(10);
		textField_2.setBounds(279, 202, 289, 33);
		frame.getContentPane().add(textField_2);
		
		textField_3 = new JTextField();
		textField_3.setColumns(10);
		textField_3.setBounds(279, 278, 289, 33);
		frame.getContentPane().add(textField_3);
		
		textField_4 = new JTextField();
		textField_4.setColumns(10);
		textField_4.setBounds(279, 442, 289, 33);
		frame.getContentPane().add(textField_4);
		
		JDateChooser dateChooser = new JDateChooser();
		dateChooser.setBounds(279, 363, 289, 28);
		frame.getContentPane().add(dateChooser);
		
		textField_5 = new JTextField();
		textField_5.setColumns(10);
		textField_5.setBounds(994, 107, 289, 33);
		frame.getContentPane().add(textField_5);
		
		passwordField = new JPasswordField();
		passwordField.setColumns(10);
		passwordField.setBounds(994, 189, 289, 33);
		frame.getContentPane().add(passwordField);
		
		JLabel lblNewLabel_1_5_1_1 = new JLabel("Gender");
		lblNewLabel_1_5_1_1.setFont(new Font("Times New Roman", Font.PLAIN, 22));
		lblNewLabel_1_5_1_1.setBounds(155, 541, 108, 28);
		frame.getContentPane().add(lblNewLabel_1_5_1_1);
		
		JComboBox comboBox = new JComboBox();
		comboBox.setFont(new Font("Times New Roman", Font.PLAIN, 20));
		comboBox.setModel(new DefaultComboBoxModel(new String[] {"----------Select----------", "Male", "Female", "Others"}));
		comboBox.setBounds(279, 541, 240, 28);
		frame.getContentPane().add(comboBox);
		
		JButton btnNewButton = new JButton("Add Faculty");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
			}
		});
		btnNewButton.setFont(new Font("Times New Roman", Font.PLAIN, 25));
		btnNewButton.setBounds(1014, 520, 258, 49);
		frame.getContentPane().add(btnNewButton);
		
		JButton btnDashboard = new JButton("Dashboard");
		btnDashboard.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Admin.main(new String[]{});
				frame.dispose();
			}
		});
		btnDashboard.setFont(new Font("Times New Roman", Font.PLAIN, 25));
		btnDashboard.setBounds(1129, 10, 258, 49);
		frame.getContentPane().add(btnDashboard);
	}
}
