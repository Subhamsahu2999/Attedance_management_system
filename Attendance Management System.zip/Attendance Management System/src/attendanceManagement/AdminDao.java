package attendanceManagement;

public class AdminDao {

}
