package attendanceManagement;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JButton;
import javax.swing.JComboBox;

public class Faculty {

	private JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Faculty window = new Faculty();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Faculty() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 1458, 771);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblWelcomeTeacher = new JLabel("Welcome, Teacher");
		lblWelcomeTeacher.setFont(new Font("Times New Roman", Font.PLAIN, 30));
		lblWelcomeTeacher.setBounds(25, 8, 266, 45);
		frame.getContentPane().add(lblWelcomeTeacher);
		
		JButton btnNewButton = new JButton("Logout");
		btnNewButton.setFont(new Font("Times New Roman", Font.PLAIN, 20));
		btnNewButton.setBounds(1277, 10, 131, 49);
		frame.getContentPane().add(btnNewButton);
		
		JButton btnUpdatePassword = new JButton("Update Password");
		btnUpdatePassword.setFont(new Font("Times New Roman", Font.PLAIN, 20));
		btnUpdatePassword.setBounds(960, 10, 259, 49);
		frame.getContentPane().add(btnUpdatePassword);
		
		JButton btnMarkStudentAttendance = new JButton("Mark Student Attendance");
		btnMarkStudentAttendance.setFont(new Font("Times New Roman", Font.PLAIN, 20));
		btnMarkStudentAttendance.setBounds(583, 186, 259, 49);
		frame.getContentPane().add(btnMarkStudentAttendance);
		
		JButton btnUpdateStudentsAttendance = new JButton("Update Student Attendance");
		btnUpdateStudentsAttendance.setFont(new Font("Times New Roman", Font.PLAIN, 20));
		btnUpdateStudentsAttendance.setBounds(583, 294, 259, 49);
		frame.getContentPane().add(btnUpdateStudentsAttendance);
		
		JLabel lblNewLabel_1_1 = new JLabel("Attendance");
		lblNewLabel_1_1.setFont(new Font("Times New Roman", Font.PLAIN, 20));
		lblNewLabel_1_1.setBounds(653, 143, 164, 33);
		frame.getContentPane().add(lblNewLabel_1_1);
		
		JLabel lblNewLabel_1_1_1_1 = new JLabel("Time Table");
		lblNewLabel_1_1_1_1.setFont(new Font("Times New Roman", Font.PLAIN, 20));
		lblNewLabel_1_1_1_1.setBounds(1106, 143, 164, 33);
		frame.getContentPane().add(lblNewLabel_1_1_1_1);
		
		JButton btnNewButton_1 = new JButton("View\r\n");
		btnNewButton_1.setFont(new Font("Times New Roman", Font.PLAIN, 20));
		btnNewButton_1.setBounds(1115, 310, 102, 33);
		frame.getContentPane().add(btnNewButton_1);
		
		JComboBox comboBox = new JComboBox();
		comboBox.setFont(new Font("Times New Roman", Font.PLAIN, 20));
		comboBox.setBounds(1197, 242, 211, 33);
		frame.getContentPane().add(comboBox);
		
		JLabel lblNewLabel_1_1_1 = new JLabel("Branch");
		lblNewLabel_1_1_1.setFont(new Font("Times New Roman", Font.PLAIN, 20));
		lblNewLabel_1_1_1.setBounds(1067, 242, 65, 33);
		frame.getContentPane().add(lblNewLabel_1_1_1);
		
		JLabel lblNewLabel_1 = new JLabel("Viewing/Adding/Removing");
		lblNewLabel_1.setFont(new Font("Times New Roman", Font.PLAIN, 20));
		lblNewLabel_1.setBounds(80, 143, 222, 33);
		frame.getContentPane().add(lblNewLabel_1);
		
		JButton btnAddStudents = new JButton("Add Students");
		btnAddStudents.setFont(new Font("Times New Roman", Font.PLAIN, 20));
		btnAddStudents.setBounds(107, 186, 164, 49);
		frame.getContentPane().add(btnAddStudents);
		
		JButton btnViewStudents = new JButton("View Students");
		btnViewStudents.setFont(new Font("Times New Roman", Font.PLAIN, 20));
		btnViewStudents.setBounds(107, 294, 164, 49);
		frame.getContentPane().add(btnViewStudents);
		
		JButton btnRemStudent = new JButton("Rem Student");
		btnRemStudent.setFont(new Font("Times New Roman", Font.PLAIN, 20));
		btnRemStudent.setBounds(107, 405, 164, 49);
		frame.getContentPane().add(btnRemStudent);
	}
}
