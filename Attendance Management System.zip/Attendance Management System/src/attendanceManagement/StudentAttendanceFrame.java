package attendanceManagement;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

import com.toedter.calendar.JDateChooser;

import java.awt.Font;
import javax.swing.JComboBox;
import javax.swing.JButton;

public class StudentAttendanceFrame {

	private JFrame frame;
	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					StudentAttendanceFrame window = new StudentAttendanceFrame();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public StudentAttendanceFrame() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 1448, 759);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblAttendanceManagementSystem = new JLabel("Attendance Management System");
		lblAttendanceManagementSystem.setFont(new Font("Times New Roman", Font.PLAIN, 35));
		lblAttendanceManagementSystem.setBounds(446, 29, 478, 95);
		frame.getContentPane().add(lblAttendanceManagementSystem);
		
		JLabel lblNewLabel_1 = new JLabel("Subject");
		lblNewLabel_1.setFont(new Font("Times New Roman", Font.PLAIN, 25));
		lblNewLabel_1.setBounds(214, 261, 117, 36);
		frame.getContentPane().add(lblNewLabel_1);
		
		JComboBox comboBox = new JComboBox();
		comboBox.setBounds(434, 261, 287, 31);
		frame.getContentPane().add(comboBox);
		
		JLabel lblNewLabel_1_1 = new JLabel("Select Date");
		lblNewLabel_1_1.setFont(new Font("Times New Roman", Font.PLAIN, 25));
		lblNewLabel_1_1.setBounds(214, 412, 117, 36);
		frame.getContentPane().add(lblNewLabel_1_1);
		
		JDateChooser dateChooser = new JDateChooser();
		dateChooser.setBounds(434, 412, 287, 36);
		frame.getContentPane().add(dateChooser);
		
		JButton btnBack = new JButton("Back");
		btnBack.setFont(new Font("Times New Roman", Font.PLAIN, 20));
		btnBack.setBounds(202, 583, 164, 49);
		frame.getContentPane().add(btnBack);
		
		JButton btnReset = new JButton("Reset");
		btnReset.setFont(new Font("Times New Roman", Font.PLAIN, 20));
		btnReset.setBounds(759, 583, 164, 49);
		frame.getContentPane().add(btnReset);
		
	}
}
